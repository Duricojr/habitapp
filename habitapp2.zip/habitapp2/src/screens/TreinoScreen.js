import { useFocusEffect } from '@react-navigation/native';
import { useCallback, useState } from 'react';
import { Alert, Linking, Modal, ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { adicionarExercicio, buscarExercicios, buscarPace, concluirExercicio, salvarPace } from '../database/db';
import { cores, sombra } from '../theme';

const REFEICOES_DEFAULT = ['☕ Café da manhã:','🍎 Lanche da manhã','🍽️ Almoço','🍌 Lanche da tarde','🥗 Jantar','💧 2L de água'];

export default function TreinoScreen() {
  const [aba, setAba]               = useState('treino'); // treino | dieta | pace
  const [exercicios, setExercicios] = useState([]);
  const [pace, setPace]             = useState({ atual: '5:30', meta: '5:00', km: '0' });
  const [historico, setHistorico]   = useState([]);
  const [mostrarForm, setMostrarForm] = useState(false);
  const [modalPace, setModalPace]   = useState(false);
  const [nome, setNome]             = useState('');
  const [duracao, setDuracao]       = useState('');
  const [paceEdit, setPaceEdit]     = useState({});
  const [refeicoes, setRefeicoes]   = useState(REFEICOES_DEFAULT);
  const [editandoDieta, setEditandoDieta] = useState(false);
  const [novaRefeicao, setNovaRefeicao]   = useState('');

  const carregar = useCallback(async () => {
    const [ex, p] = await Promise.all([buscarExercicios(), buscarPace()]);
    setExercicios(ex);
    if (p) setPace(p);
  }, []);

  useFocusEffect(useCallback(() => { carregar(); }, [carregar]));

  const salvarExercicio = async () => {
    if (!nome.trim()) return;
    await adicionarExercicio(nome.trim(), duracao.trim() || '—');
    setNome(''); setDuracao(''); setMostrarForm(false); carregar();
  };

  const registrarCorrida = async () => {
    const hoje = new Date().toLocaleDateString('pt-BR');
    const novo = { data: hoje, pace: paceEdit.atual || pace.atual, km: paceEdit.km || pace.km };
    setHistorico(prev => [novo, ...prev]);
    await salvarPace(paceEdit.atual || pace.atual, paceEdit.meta || pace.meta, paceEdit.km || pace.km);
    setModalPace(false); carregar();
  };

  const abrirStrava = async () => {
    try {
      await Linking.openURL('strava://');
    } catch {
      try {
        await Linking.openURL('https://www.strava.com');
      } catch {
        Alert.alert('Strava não encontrado', 'Instale o Strava na sua loja de apps.');
      }
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: cores.fundo }}>

      {/* ── Abas ── */}
      <View style={s.abaRow}>
        {[['treino','💪 Treino'],['dieta','🥗 Dieta'],['pace','🏃 Pace']].map(([k, label]) => (
          <TouchableOpacity key={k} style={[s.abaBtn, aba===k && s.abaBtnAtivo]} onPress={() => setAba(k)}>
            <Text style={[s.abaBtnTxt, aba===k && s.abaBtnTxtAtivo]}>{label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* ── ABA TREINO ── */}
      {aba === 'treino' && (
        <ScrollView contentContainerStyle={s.content}>
          <Text style={s.titulo}>Treino</Text>
          {exercicios.map(ex => (
            <TouchableOpacity key={ex.id} style={s.card} onPress={() => { concluirExercicio(ex.id, !ex.concluido); carregar(); }}>
              <View style={[s.iconBox, { backgroundColor: ex.concluido ? '#C8F0DE' : '#D6EAFF' }]}>
                <Text style={{ fontSize: 18 }}>{ex.concluido ? '✓' : '▶'}</Text>
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[s.exNome, ex.concluido && s.riscado]}>{ex.nome}</Text>
                <Text style={s.exDur}>{ex.duracao}</Text>
              </View>
              {ex.concluido && <View style={s.badge}><Text style={s.badgeTxt}>Feito</Text></View>}
            </TouchableOpacity>
          ))}
          {mostrarForm && (
            <View style={s.form}>
              <TextInput style={s.input} placeholder="Nome do exercício" value={nome} onChangeText={setNome} />
              <TextInput style={s.input} placeholder="Duração (ex: 30 min)" value={duracao} onChangeText={setDuracao} />
              <View style={s.rowBtn}>
                <TouchableOpacity style={[s.btn, { backgroundColor: cores.verde }]} onPress={salvarExercicio}><Text style={s.btnTxt}>Salvar</Text></TouchableOpacity>
                <TouchableOpacity style={[s.btn, { backgroundColor: cores.cinza }]} onPress={() => setMostrarForm(false)}><Text style={s.btnTxt}>Cancelar</Text></TouchableOpacity>
              </View>
            </View>
          )}
          <TouchableOpacity style={s.btnOutline} onPress={() => setMostrarForm(!mostrarForm)}>
            <Text style={s.btnOutlineTxt}>+ Adicionar exercício</Text>
          </TouchableOpacity>
        </ScrollView>
      )}

      {/* ── ABA DIETA ── */}
      {aba === 'dieta' && (
        <ScrollView contentContainerStyle={s.content}>
          <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 16, gap: 10 }}>
            <Text style={[s.titulo, { flex: 1, marginBottom: 0 }]}>Dieta</Text>
            <TouchableOpacity style={[s.btnPeq, { backgroundColor: editandoDieta ? cores.verde : cores.azul }]} onPress={() => setEditandoDieta(e => !e)}>
              <Text style={s.btnPeqTxt}>{editandoDieta ? '✓ Pronto' : '✏ Editar'}</Text>
            </TouchableOpacity>
          </View>
          {refeicoes.map((r, i) => (
            <View key={i} style={s.dietaCard}>
              <Text style={s.dietaTxt}>{r}</Text>
              {editandoDieta && (
                <TouchableOpacity onPress={() => setRefeicoes(prev => prev.filter((_, idx) => idx !== i))}>
                  <Text style={{ color: cores.coral, fontSize: 18, fontWeight: '700' }}>×</Text>
                </TouchableOpacity>
              )}
            </View>
          ))}
          {editandoDieta && (
            <View style={s.form}>
              <TextInput style={s.input} placeholder="Nova refeição (ex: 🍌 Lanche)" value={novaRefeicao} onChangeText={setNovaRefeicao} />
              <TouchableOpacity style={[s.btn, { backgroundColor: cores.verde, alignSelf: 'stretch' }]}
                onPress={() => { if (novaRefeicao.trim()) { setRefeicoes(prev => [...prev, novaRefeicao.trim()]); setNovaRefeicao(''); } }}>
                <Text style={s.btnTxt}>Adicionar</Text>
              </TouchableOpacity>
            </View>
          )}
        </ScrollView>
      )}

      {/* ── ABA PACE ── */}
      {aba === 'pace' && (
        <ScrollView contentContainerStyle={s.content}>
          <Text style={s.titulo}>Corrida</Text>

          {/* Cards de pace */}
          <View style={s.paceRow}>
            {[['atual','min/km atual',cores.azul],['meta','meta',cores.verde],['km','km semana',cores.roxo]].map(([key, lbl, cor]) => (
              <View key={key} style={[s.paceCard, { borderTopWidth: 3, borderColor: cor }]}>
                <Text style={[s.paceVal, { color: cor }]}>{pace[key]}</Text>
                <Text style={s.paceLbl}>{lbl}</Text>
              </View>
            ))}
          </View>

          {/* Botões */}
          <TouchableOpacity style={[s.btnGrande, { backgroundColor: cores.azul, marginBottom: 10 }]} onPress={() => { setPaceEdit({...pace}); setModalPace(true); }}>
            <Text style={s.btnGrandeTxt}>+ Registrar corrida</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[s.btnGrande, { backgroundColor: '#FC4C02' }]} onPress={abrirStrava}>
            <Text style={s.btnGrandeTxt}>🏃 Abrir Strava</Text>
          </TouchableOpacity>

          {/* Histórico */}
          {historico.length > 0 && (
            <>
              <Text style={[s.titulo, { fontSize: 18, marginTop: 20 }]}>Histórico</Text>
              {historico.map((h, i) => (
                <View key={i} style={s.histCard}>
                  <View style={s.histIcone}><Text style={{ fontSize: 20 }}>🏃</Text></View>
                  <View style={{ flex: 1 }}>
                    <Text style={s.histData}>{h.data}</Text>
                    <Text style={s.histDetalhe}>{h.km} km · {h.pace} min/km</Text>
                  </View>
                </View>
              ))}
            </>
          )}
          {historico.length === 0 && (
            <View style={[s.form, { alignItems: 'center', marginTop: 20 }]}>
              <Text style={{ fontSize: 32 }}>🏃</Text>
              <Text style={s.vazio}>Nenhuma corrida registrada ainda.</Text>
            </View>
          )}
        </ScrollView>
      )}

      {/* ── Modal registrar corrida ── */}
      <Modal visible={modalPace} animationType="slide" transparent>
        <View style={s.overlay}>
          <View style={s.modalCard}>
            <Text style={s.modalTitulo}>Registrar corrida</Text>
            {[['atual','Pace (min/km)'],['km','Distância (km)'],['meta','Meta de pace']].map(([key, ph]) => (
              <TextInput key={key} style={s.input} placeholder={ph} value={String(paceEdit[key]||'')}
                onChangeText={v => setPaceEdit(p => ({...p,[key]:v}))} keyboardType="default" />
            ))}
            <View style={s.rowBtn}>
              <TouchableOpacity style={[s.btn, { backgroundColor: cores.cinza }]} onPress={() => setModalPace(false)}><Text style={s.btnTxt}>Cancelar</Text></TouchableOpacity>
              <TouchableOpacity style={[s.btn, { backgroundColor: cores.verde }]} onPress={registrarCorrida}><Text style={s.btnTxt}>Salvar</Text></TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const s = StyleSheet.create({
  content:         { padding: 16, paddingBottom: 30 },
  titulo:          { fontSize: 26, fontWeight: '700', color: cores.texto, marginBottom: 12 },
  abaRow:          { flexDirection: 'row', backgroundColor: cores.branco, borderBottomWidth: 0.5, borderColor: cores.borda },
  abaBtn:          { flex: 1, paddingVertical: 13, alignItems: 'center' },
  abaBtnAtivo:     { borderBottomWidth: 3, borderColor: cores.azul },
  abaBtnTxt:       { fontSize: 13, fontWeight: '600', color: cores.texto2 },
  abaBtnTxtAtivo:  { color: cores.azul },
  card:            { flexDirection: 'row', alignItems: 'center', backgroundColor: cores.branco, borderRadius: 14, padding: 12, marginBottom: 8, gap: 10, ...sombra },
  iconBox:         { width: 38, height: 38, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  exNome:          { fontSize: 15, color: cores.texto, fontWeight: '500' },
  exDur:           { fontSize: 12, color: cores.texto2, marginTop: 2 },
  riscado:         { textDecorationLine: 'line-through', color: cores.cinza },
  badge:           { backgroundColor: '#C8F0DE', borderRadius: 20, paddingHorizontal: 8, paddingVertical: 3 },
  badgeTxt:        { fontSize: 11, color: '#1B6B44', fontWeight: '600' },
  form:            { backgroundColor: cores.fundo2, borderRadius: 12, padding: 12, marginBottom: 10, gap: 8 },
  input:           { backgroundColor: cores.branco, borderRadius: 10, padding: 10, fontSize: 14, borderWidth: 0.5, borderColor: cores.borda },
  rowBtn:          { flexDirection: 'row', gap: 8 },
  btn:             { flex: 1, borderRadius: 10, padding: 11, alignItems: 'center' },
  btnTxt:          { color: cores.branco, fontWeight: '600', fontSize: 14 },
  btnOutline:      { borderWidth: 1.5, borderColor: cores.azul, borderRadius: 12, padding: 12, alignItems: 'center', marginBottom: 8, borderStyle: 'dashed' },
  btnOutlineTxt:   { color: cores.azul, fontWeight: '600', fontSize: 14 },
  btnGrande:       { borderRadius: 14, padding: 14, alignItems: 'center', marginBottom: 4 },
  btnGrandeTxt:    { color: cores.branco, fontWeight: '700', fontSize: 15 },
  btnPeq:          { borderRadius: 10, paddingVertical: 7, paddingHorizontal: 14 },
  btnPeqTxt:       { color: cores.branco, fontWeight: '600', fontSize: 13 },
  dietaCard:       { flexDirection: 'row', alignItems: 'center', backgroundColor: cores.branco, borderRadius: 12, padding: 14, marginBottom: 8, ...sombra },
  dietaTxt:        { flex: 1, fontSize: 15, color: cores.texto },
  paceRow:         { flexDirection: 'row', gap: 8, marginBottom: 16 },
  paceCard:        { flex: 1, backgroundColor: cores.branco, borderRadius: 12, padding: 10, alignItems: 'center', ...sombra },
  paceVal:         { fontSize: 22, fontWeight: '700' },
  paceLbl:         { fontSize: 11, color: cores.texto2, marginTop: 2, textAlign: 'center' },
  histCard:        { flexDirection: 'row', alignItems: 'center', backgroundColor: cores.branco, borderRadius: 12, padding: 12, marginBottom: 8, gap: 10, ...sombra },
  histIcone:       { width: 44, height: 44, borderRadius: 22, backgroundColor: '#FFE8DC', alignItems: 'center', justifyContent: 'center' },
  histData:        { fontSize: 13, fontWeight: '700', color: cores.texto },
  histDetalhe:     { fontSize: 13, color: cores.texto2, marginTop: 2 },
  vazio:           { fontSize: 13, color: cores.texto2, fontStyle: 'italic', textAlign: 'center', marginTop: 8 },
  overlay:         { flex: 1, backgroundColor: '#00000055', justifyContent: 'flex-end' },
  modalCard:       { backgroundColor: cores.branco, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20, gap: 10 },
  modalTitulo:     { fontSize: 18, fontWeight: '700', color: cores.texto, marginBottom: 4 },
});
