import React, { useState, useCallback } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import * as DocumentPicker from 'expo-document-picker';
import * as IntentLauncher from 'expo-intent-launcher';
import * as FileSystem from 'expo-file-system/legacy';
import { cores, sombra } from '../theme';
import { buscarLivros, adicionarLivro } from '../database/db';

export default function LivrosScreen() {
  const [livros, setLivros] = useState([]);

  const carregar = useCallback(async () => { setLivros(await buscarLivros()); }, []);
  useFocusEffect(useCallback(() => { carregar(); }, [carregar]));

  const adicionarPDF = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: 'application/pdf',
        copyToCacheDirectory: true,
      });
      if (!result.canceled && result.assets?.[0]) {
        const { name, uri } = result.assets[0];
        const destino = FileSystem.documentDirectory + name;
        await FileSystem.copyAsync({ from: uri, to: destino });
        await adicionarLivro(name.replace('.pdf', ''), destino);
        carregar();
      }
    } catch (e) {
      Alert.alert('Erro', 'Não foi possível adicionar o PDF.');
    }
  };

  const abrirPDF = async (livro) => {
    try {
      const uri = await FileSystem.getContentUriAsync(livro.caminho);
      await IntentLauncher.startActivityAsync('android.intent.action.VIEW', {
        data: uri,
        flags: 1,
        type: 'application/pdf',
      });
    } catch (e) {
      Alert.alert('Erro', 'Nenhum app de PDF encontrado.\nInstale o Adobe Acrobat ou outro leitor de PDF.');
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: cores.fundo }}>
      <ScrollView contentContainerStyle={s.content}>
        <Text style={s.titulo}>Livros</Text>
        <Text style={s.sub}>{livros.length} livro{livros.length !== 1 ? 's' : ''} adicionado{livros.length !== 1 ? 's' : ''}</Text>

        {livros.length === 0 && (
          <View style={s.vazioCard}>
            <Text style={{ fontSize: 48, textAlign: 'center' }}>📚</Text>
            <Text style={s.vazioTxt}>Nenhum livro ainda.{'\n'}Adicione um PDF para começar!</Text>
          </View>
        )}

        {livros.map(livro => (
          <TouchableOpacity key={livro.id} style={s.livroCard} onPress={() => abrirPDF(livro)}>
            <View style={s.livroIcone}>
              <Text style={{ fontSize: 28 }}>📖</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={s.livroTitulo} numberOfLines={2}>{livro.titulo}</Text>
              <Text style={s.livroCaminho}>Toque para abrir</Text>
            </View>
            <Text style={{ fontSize: 20, color: cores.texto2 }}>›</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <View style={s.footer}>
        <TouchableOpacity style={s.btnAdd} onPress={adicionarPDF}>
          <Text style={s.btnAddTxt}>+ Adicionar PDF</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  content: { padding: 16, paddingBottom: 100 },
  titulo: { fontSize: 26, fontWeight: '700', color: cores.texto },
  sub: { fontSize: 13, color: cores.texto2, marginBottom: 20, marginTop: 2 },
  vazioCard: { alignItems: 'center', padding: 40, backgroundColor: cores.branco, borderRadius: 20, gap: 12 },
  vazioTxt: { fontSize: 15, color: cores.texto2, textAlign: 'center', lineHeight: 22 },
  livroCard: { flexDirection: 'row', alignItems: 'center', backgroundColor: cores.branco, borderRadius: 16, padding: 14, marginBottom: 10, gap: 12 },
  livroIcone: { width: 52, height: 52, borderRadius: 12, backgroundColor: '#FFF0E0', alignItems: 'center', justifyContent: 'center' },
  livroTitulo: { fontSize: 15, fontWeight: '600', color: '#3D3D3A' },
  livroCaminho: { fontSize: 12, color: '#1B9E75', marginTop: 3 },
  footer: { position: 'absolute', bottom: 0, left: 0, right: 0, padding: 16, backgroundColor: '#F7F7F5', borderTopWidth: 0.5, borderColor: '#E0E0DC' },
  btnAdd: { backgroundColor: '#175FA5', borderRadius: 14, padding: 15, alignItems: 'center' },
  btnAddTxt: { color: '#FFFFFF', fontWeight: '700', fontSize: 16 },
});
