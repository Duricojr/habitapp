import { useFocusEffect } from '@react-navigation/native';
import { useCallback, useState } from 'react';
import { ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { buscarDiario, salvarDiario } from '../database/db';
import { cores, sombra } from '../theme';

const HUMORES  = ['😔','😐','🙂','😄','🤩'];
const DIAS_PT  = ['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado'];
const MESES_PT = ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'];

export default function DiarioScreen() {
  const [texto, setTexto] = useState('');
  const [humor, setHumor] = useState(null);
  const [salvo, setSalvo] = useState(false);

  const hoje    = new Date();
  const dataKey = hoje.toISOString().split('T')[0];
  const dataLabel = `${DIAS_PT[hoje.getDay()]}, ${hoje.getDate()} de ${MESES_PT[hoje.getMonth()]}`;

  useFocusEffect(useCallback(() => {
    buscarDiario(dataKey).then(e => { if (e) { setTexto(e.texto||''); setHumor(e.humor||null); } });
    setSalvo(false);
  }, []));

  const salvar = async () => {
    await salvarDiario(dataKey, texto, humor||'');
    setSalvo(true); setTimeout(() => setSalvo(false), 3000);
  };

  return (
    <ScrollView style={s.scroll} contentContainerStyle={s.content} keyboardShouldPersistTaps="handled">
      <Text style={s.titulo}>Diário</Text>
      <Text style={s.sub}>{dataLabel}</Text>
      <Text style={s.label}>Como foi o seu dia?</Text>
      <TextInput style={s.textarea} multiline placeholder="Escreva seus pensamentos aqui..." placeholderTextColor={cores.cinza} value={texto} onChangeText={setTexto} textAlignVertical="top" />
      <Text style={s.label}>Humor do dia</Text>
      <View style={s.humorRow}>
        {HUMORES.map(h => (
          <TouchableOpacity key={h} style={[s.humorBtn, humor===h&&s.humorBtnSel]} onPress={() => setHumor(h)}>
            <Text style={s.humorEmoji}>{h}</Text>
          </TouchableOpacity>
        ))}
      </View>
      {humor && <Text style={s.humorSel}>Selecionado: {humor}</Text>}
      <TouchableOpacity style={s.btnSalvar} onPress={salvar}>
        <Text style={s.btnSalvarTxt}>Salvar entrada</Text>
      </TouchableOpacity>
      {salvo && <View style={s.okCard}><Text style={s.okTxt}>✓ Entrada salva com sucesso!</Text></View>}
    </ScrollView>
  );
}

const s = StyleSheet.create({
  scroll: { flex: 1, backgroundColor: cores.fundo },
  content: { padding: 16, paddingBottom: 40 },
  titulo: { fontSize: 26, fontWeight: '700', color: cores.texto },
  sub: { fontSize: 13, color: cores.texto2, marginBottom: 20, marginTop: 2 },
  label: { fontSize: 14, fontWeight: '600', color: cores.texto, marginBottom: 8 },
  textarea: { backgroundColor: cores.branco, borderRadius: 14, padding: 14, fontSize: 15, color: cores.texto, minHeight: 180, borderWidth: 0.5, borderColor: cores.borda, ...sombra, marginBottom: 20 },
  humorRow: { flexDirection: 'row', gap: 8, marginBottom: 8 },
  humorBtn: { flex: 1, alignItems: 'center', padding: 8, borderRadius: 12, backgroundColor: cores.fundo2 },
  humorBtnSel: { backgroundColor: cores.branco, borderWidth: 2, borderColor: cores.azul },
  humorEmoji: { fontSize: 28 },
  humorSel: { fontSize: 13, color: cores.verde, marginBottom: 16, textAlign: 'center' },
  btnSalvar: { backgroundColor: cores.azul, borderRadius: 14, padding: 16, alignItems: 'center', marginTop: 8 },
  btnSalvarTxt: { color: cores.branco, fontWeight: '700', fontSize: 16 },
  okCard: { backgroundColor: '#DFFAED', borderRadius: 12, padding: 12, marginTop: 12, alignItems: 'center' },
  okTxt: { color: cores.verde, fontWeight: '600', fontSize: 14 },
});
