import React, { useState, useEffect, useRef } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import { cores, sombra } from '../theme';

export default function EstudosScreen() {
  const [minutos, setMinutos]   = useState(25);
  const [segundos, setSegundos] = useState(0);
  const [rodando, setRodando]   = useState(false);
  const [duracao, setDuracao]   = useState(25);
  const intervalRef             = useRef(null);

  useEffect(() => {
    if (rodando) {
      intervalRef.current = setInterval(() => {
        setSegundos(s => {
          if (s > 0) return s - 1;
          setMinutos(m => {
            if (m > 0) return m - 1;
            setRodando(false); clearInterval(intervalRef.current); return 0;
          });
          return 59;
        });
      }, 1000);
    } else { clearInterval(intervalRef.current); }
    return () => clearInterval(intervalRef.current);
  }, [rodando]);

  const resetar = () => { setRodando(false); setMinutos(duracao); setSegundos(0); };
  const selecionarDuracao = (min) => { if (rodando) return; setDuracao(min); setMinutos(min); setSegundos(0); };
  const progresso = 1 - (minutos * 60 + segundos) / (duracao * 60);

  return (
    <ScrollView style={s.scroll} contentContainerStyle={s.content}>
      <Text style={s.titulo}>Estudos</Text>
      <Text style={s.sub}>Foco total · Pomodoro</Text>
      <View style={s.timerCard}>
        <Text style={s.timer}>{String(minutos).padStart(2,'0')}:{String(segundos).padStart(2,'0')}</Text>
        <Text style={s.timerSub}>{rodando ? '⏳ Estudando... foco total!' : minutos===0&&segundos===0 ? '✅ Sessão concluída!' : 'Pronto para começar'}</Text>
        <View style={s.progWrap}><View style={[s.progBar, { width: `${Math.round(progresso*100)}%` }]} /></View>
      </View>
      <Text style={[s.sub, { marginTop: 16 }]}>Duração da sessão</Text>
      <View style={s.duracaoRow}>
        {[15,25,30,45,60].map(m => (
          <TouchableOpacity key={m} style={[s.duracaoBtn, duracao===m&&!rodando&&s.duracaoBtnAtivo]} onPress={() => selecionarDuracao(m)}>
            <Text style={[s.duracaoBtnTxt, duracao===m&&!rodando&&{color:cores.branco}]}>{m}min</Text>
          </TouchableOpacity>
        ))}
      </View>
      <View style={s.btnRow}>
        <TouchableOpacity style={[s.btnGrande, { backgroundColor: rodando ? cores.coral : cores.azul }]} onPress={() => setRodando(r => !r)}>
          <Text style={s.btnGrandeTxt}>{rodando ? 'Pausar ⏸' : 'Iniciar ▶'}</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[s.btnGrande, { backgroundColor: cores.cinza }]} onPress={resetar}>
          <Text style={s.btnGrandeTxt}>Resetar</Text>
        </TouchableOpacity>
      </View>
      <View style={s.avisoCard}>
        <Text style={s.avisoTxt}>💡 Dica: ative o Foco ou Não Perturbe no celular para bloquear notificações durante o estudo.</Text>
      </View>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  scroll: { flex: 1, backgroundColor: cores.fundo },
  content: { padding: 16, paddingBottom: 30, alignItems: 'center' },
  titulo: { fontSize: 26, fontWeight: '700', color: cores.texto, alignSelf: 'flex-start' },
  sub: { fontSize: 13, color: cores.texto2, alignSelf: 'flex-start', marginBottom: 10 },
  timerCard: { width: '100%', backgroundColor: cores.branco, borderRadius: 24, padding: 28, alignItems: 'center', marginVertical: 16, ...sombra },
  timer: { fontSize: 72, fontWeight: '700', color: cores.texto, letterSpacing: 2 },
  timerSub: { fontSize: 14, color: cores.texto2, marginTop: 8 },
  progWrap: { width: '100%', height: 8, backgroundColor: cores.fundo2, borderRadius: 10, marginTop: 20, overflow: 'hidden' },
  progBar: { height: 8, backgroundColor: cores.verde, borderRadius: 10 },
  duracaoRow: { flexDirection: 'row', gap: 8, marginBottom: 20 },
  duracaoBtn: { paddingHorizontal: 14, paddingVertical: 9, borderRadius: 20, backgroundColor: cores.fundo2, borderWidth: 0.5, borderColor: cores.borda },
  duracaoBtnAtivo: { backgroundColor: cores.azul, borderColor: cores.azul },
  duracaoBtnTxt: { fontSize: 13, fontWeight: '600', color: cores.texto2 },
  btnRow: { flexDirection: 'row', gap: 10, width: '100%', marginBottom: 20 },
  btnGrande: { flex: 1, borderRadius: 14, padding: 14, alignItems: 'center' },
  btnGrandeTxt: { color: cores.branco, fontWeight: '700', fontSize: 15 },
  avisoCard: { backgroundColor: '#FFF8D6', borderRadius: 14, padding: 14, width: '100%' },
  avisoTxt: { fontSize: 13, color: '#7A5F00', lineHeight: 20 },
});
