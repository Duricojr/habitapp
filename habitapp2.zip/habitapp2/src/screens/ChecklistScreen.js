import React, { useState, useCallback } from 'react';
import { View, Text, ScrollView, TouchableOpacity, TextInput, StyleSheet, Modal } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { cores, sombra } from '../theme';
import { buscarChecklistHoje, adicionarChecklistItem, concluirChecklistItem } from '../database/db';

const PERIODOS = ['Manhã','Tarde','Noite'];
const DIAS     = ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'];
const DIAS_FULL = ['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado'];
const COR = {
  'Manhã': { t: cores.amarelo, f: cores.manhaFundo },
  'Tarde': { t: cores.azul2,   f: cores.tardeFundo },
  'Noite': { t: cores.roxo,    f: cores.noiteFundo }
};
const diaHoje = new Date().getDay();

export default function ChecklistScreen() {
  const [aba, setAba]         = useState('hoje');   // 'hoje' | 'historico'
  const [periodo, setPeriodo] = useState('Manhã');
  const [itens, setItens]     = useState([]);
  const [modal, setModal]     = useState(false);
  const [nome, setNome]       = useState('');
  const [perForm, setPerForm] = useState('Manhã');
  const [diasSel, setDiasSel] = useState(new Set([0,1,2,3,4,5,6]));

  // Histórico: dia selecionado
  const [diaHist, setDiaHist] = useState(diaHoje);
  const [itensHist, setItensHist] = useState({ 'Manhã': [], 'Tarde': [], 'Noite': [] });

  const carregar = useCallback(async () => {
    setItens(await buscarChecklistHoje(periodo, diaHoje));
  }, [periodo]);

  const carregarHist = useCallback(async (dia) => {
    const [m, t, n] = await Promise.all([
      buscarChecklistHoje('Manhã', dia),
      buscarChecklistHoje('Tarde', dia),
      buscarChecklistHoje('Noite', dia),
    ]);
    setItensHist({ 'Manhã': m, 'Tarde': t, 'Noite': n });
  }, []);

  useFocusEffect(useCallback(() => {
    if (aba === 'hoje') carregar();
    else carregarHist(diaHist);
  }, [aba, periodo, diaHist]));

  const toggleItem = async (id, atual) => {
    await concluirChecklistItem(id, !atual);
    carregar();
  };

  const salvar = async () => {
    if (!nome.trim() || diasSel.size === 0) return;
    await adicionarChecklistItem(nome.trim(), perForm, [...diasSel].sort().join(''));
    setNome(''); setDiasSel(new Set([0,1,2,3,4,5,6]));
    setModal(false); carregar();
  };

  const toggleDia = (idx) => setDiasSel(prev => {
    const n = new Set(prev);
    n.has(idx) ? n.delete(idx) : n.add(idx);
    return n;
  });

  return (
    <View style={{ flex: 1, backgroundColor: cores.fundo }}>

      {/* ── Abas principais ── */}
      <View style={s.abaRow}>
        <TouchableOpacity style={[s.abaBtn, aba==='hoje' && s.abaBtnAtivo]} onPress={() => setAba('hoje')}>
          <Text style={[s.abaBtnTxt, aba==='hoje' && s.abaBtnTxtAtivo]}>Hoje</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[s.abaBtn, aba==='historico' && s.abaBtnAtivo]} onPress={() => { setAba('historico'); carregarHist(diaHist); }}>
          <Text style={[s.abaBtnTxt, aba==='historico' && s.abaBtnTxtAtivo]}>Histórico</Text>
        </TouchableOpacity>
      </View>

      {aba === 'hoje' ? (
        <ScrollView contentContainerStyle={s.content}>
          <Text style={s.titulo}>Checklist</Text>

          {/* Seletor de período */}
          <View style={s.periodoRow}>
            {PERIODOS.map(p => (
              <TouchableOpacity key={p} style={[s.periodoBtn, periodo===p && { backgroundColor: COR[p].t }]} onPress={() => setPeriodo(p)}>
                <Text style={[s.periodoBtnTxt, periodo===p && { color: cores.branco }]}>{p}</Text>
              </TouchableOpacity>
            ))}
          </View>

          <View style={[s.lista, { backgroundColor: COR[periodo].f }]}>
            <Text style={[s.periodoTitulo, { color: COR[periodo].t }]}>{periodo}</Text>
            {itens.length === 0
              ? <Text style={s.vazio}>Nenhum hábito para hoje.</Text>
              : itens.map(item => (
                <TouchableOpacity key={item.id} style={s.itemRow} onPress={() => toggleItem(item.id, item.concluido_hoje)}>
                  <Text style={{ fontSize: 18, color: item.concluido_hoje ? cores.verde : cores.texto2 }}>
                    {item.concluido_hoje ? '✓' : '○'}
                  </Text>
                  <View style={{ flex: 1 }}>
                    <Text style={[s.itemNome, item.concluido_hoje && s.riscado]}>{item.nome}</Text>
                    <Text style={s.itemDias}>{(item.dias||'0123456').split('').map(d=>DIAS[parseInt(d)]).join('  ')}</Text>
                  </View>
                </TouchableOpacity>
              ))
            }
          </View>

          <TouchableOpacity style={s.btnAdd} onPress={() => setModal(true)}>
            <Text style={s.btnAddTxt}>+ Novo hábito</Text>
          </TouchableOpacity>
        </ScrollView>

      ) : (
        /* ── ABA HISTÓRICO ── */
        <ScrollView contentContainerStyle={s.content}>
          <Text style={s.titulo}>Histórico</Text>
          <Text style={s.sub}>Veja seus hábitos por dia da semana</Text>

          {/* Seletor de dia */}
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 16 }}>
            <View style={{ flexDirection: 'row', gap: 8, paddingHorizontal: 2 }}>
              {DIAS.map((d, i) => (
                <TouchableOpacity key={i}
                  style={[s.diaHistBtn, diaHist===i && s.diaHistBtnAtivo, i===diaHoje && { borderWidth: 2, borderColor: cores.azul }]}
                  onPress={() => { setDiaHist(i); carregarHist(i); }}>
                  <Text style={[s.diaHistTxt, diaHist===i && { color: cores.branco }]}>{d}</Text>
                  {i === diaHoje && <Text style={[s.diaHistSub, diaHist===i && { color: '#cde' }]}>hoje</Text>}
                </TouchableOpacity>
              ))}
            </View>
          </ScrollView>

          <Text style={s.diaLabel}>{DIAS_FULL[diaHist]}</Text>

          {PERIODOS.map(p => (
            <View key={p} style={[s.lista, { backgroundColor: COR[p].f, marginBottom: 12 }]}>
              <Text style={[s.periodoTitulo, { color: COR[p].t }]}>{p}</Text>
              {itensHist[p].length === 0
                ? <Text style={s.vazio}>Nenhum hábito neste dia.</Text>
                : itensHist[p].map(item => (
                  <View key={item.id} style={s.itemRow}>
                    <Text style={{ fontSize: 16, color: item.concluido_hoje ? cores.verde : cores.texto2 }}>
                      {item.concluido_hoje ? '✓' : '○'}
                    </Text>
                    <Text style={[s.itemNome, item.concluido_hoje && s.riscado]}>{item.nome}</Text>
                  </View>
                ))
              }
            </View>
          ))}
        </ScrollView>
      )}

      {/* ── Modal novo hábito ── */}
      <Modal visible={modal} animationType="slide" transparent>
        <View style={s.overlay}>
          <View style={s.modalCard}>
            <Text style={s.modalTitulo}>Novo hábito</Text>
            <Text style={s.label}>Nome</Text>
            <TextInput style={s.input} placeholder="Nome do hábito" value={nome} onChangeText={setNome} />
            <Text style={s.label}>Período</Text>
            <View style={s.periodoRow}>
              {PERIODOS.map(p => (
                <TouchableOpacity key={p} style={[s.periodoBtn, perForm===p && { backgroundColor: COR[p].t }]} onPress={() => setPerForm(p)}>
                  <Text style={[s.periodoBtnTxt, perForm===p && { color: cores.branco }]}>{p}</Text>
                </TouchableOpacity>
              ))}
            </View>
            <Text style={s.label}>Dias da semana</Text>
            <View style={s.diasRow}>
              {DIAS.map((d, i) => (
                <TouchableOpacity key={i} style={[s.diaBtn, diasSel.has(i) && { backgroundColor: cores.azul }]} onPress={() => toggleDia(i)}>
                  <Text style={[s.diaBtnTxt, diasSel.has(i) && { color: cores.branco }]}>{d}</Text>
                </TouchableOpacity>
              ))}
            </View>
            <View style={s.rowBtn}>
              <TouchableOpacity style={[s.btn, { backgroundColor: cores.cinza }]} onPress={() => setModal(false)}>
                <Text style={s.btnTxt}>Cancelar</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[s.btn, { backgroundColor: cores.verde }]} onPress={salvar}>
                <Text style={s.btnTxt}>Salvar</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const s = StyleSheet.create({
  content:         { padding: 16, paddingBottom: 30 },
  titulo:          { fontSize: 26, fontWeight: '700', color: cores.texto, marginBottom: 4 },
  sub:             { fontSize: 13, color: cores.texto2, marginBottom: 12 },
  abaRow:          { flexDirection: 'row', backgroundColor: cores.branco, borderBottomWidth: 0.5, borderColor: cores.borda },
  abaBtn:          { flex: 1, paddingVertical: 14, alignItems: 'center' },
  abaBtnAtivo:     { borderBottomWidth: 3, borderColor: cores.azul },
  abaBtnTxt:       { fontSize: 14, fontWeight: '600', color: cores.texto2 },
  abaBtnTxtAtivo:  { color: cores.azul },
  periodoRow:      { flexDirection: 'row', gap: 8, marginBottom: 14 },
  periodoBtn:      { flex: 1, borderRadius: 20, paddingVertical: 8, alignItems: 'center', backgroundColor: cores.fundo2, borderWidth: 0.5, borderColor: cores.borda },
  periodoBtnTxt:   { fontSize: 13, fontWeight: '600', color: cores.texto2 },
  periodoTitulo:   { fontSize: 14, fontWeight: '700', marginBottom: 10 },
  lista:           { borderRadius: 16, padding: 14, marginBottom: 12, ...sombra },
  itemRow:         { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 10, borderBottomWidth: 0.5, borderColor: cores.borda },
  itemNome:        { fontSize: 15, color: cores.texto, fontWeight: '500' },
  itemDias:        { fontSize: 11, color: cores.texto2, marginTop: 2 },
  riscado:         { textDecorationLine: 'line-through', color: cores.cinza },
  vazio:           { fontSize: 13, color: cores.texto2, fontStyle: 'italic', paddingVertical: 8 },
  btnAdd:          { backgroundColor: cores.azul, borderRadius: 14, padding: 14, alignItems: 'center' },
  btnAddTxt:       { color: cores.branco, fontWeight: '700', fontSize: 15 },
  diaHistBtn:      { paddingHorizontal: 14, paddingVertical: 10, borderRadius: 20, backgroundColor: cores.fundo2, alignItems: 'center', minWidth: 52 },
  diaHistBtnAtivo: { backgroundColor: cores.azul },
  diaHistTxt:      { fontSize: 13, fontWeight: '700', color: cores.texto2 },
  diaHistSub:      { fontSize: 9, color: cores.azul, marginTop: 1 },
  diaLabel:        { fontSize: 18, fontWeight: '700', color: cores.texto, marginBottom: 12 },
  overlay:         { flex: 1, backgroundColor: '#00000055', justifyContent: 'flex-end' },
  modalCard:       { backgroundColor: cores.branco, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20, gap: 10 },
  modalTitulo:     { fontSize: 18, fontWeight: '700', color: cores.texto, marginBottom: 4 },
  label:           { fontSize: 13, color: cores.texto2, fontWeight: '500' },
  input:           { backgroundColor: cores.fundo2, borderRadius: 10, padding: 12, fontSize: 14, borderWidth: 0.5, borderColor: cores.borda },
  diasRow:         { flexDirection: 'row', gap: 5 },
  diaBtn:          { flex: 1, borderRadius: 8, paddingVertical: 7, alignItems: 'center', backgroundColor: cores.fundo2, borderWidth: 0.5, borderColor: cores.borda },
  diaBtnTxt:       { fontSize: 10, fontWeight: '600', color: cores.texto2 },
  rowBtn:          { flexDirection: 'row', gap: 10, marginTop: 6 },
  btn:             { flex: 1, borderRadius: 12, padding: 13, alignItems: 'center' },
  btnTxt:          { color: cores.branco, fontWeight: '700', fontSize: 14 },
});
