import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import * as FileSystem from 'expo-file-system/legacy';
import * as ImagePicker from 'expo-image-picker';
import { useCallback, useState } from 'react';
import { Alert, Image, ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { buscarChecklistHoje, buscarExercicios, buscarLivros, concluirChecklistItem } from '../database/db';
import { cores, sombra } from '../theme';

const FOTO_URI  = FileSystem.documentDirectory + 'foto_usuario.jpg';
const DIAS_PT   = ['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado'];
const diaHojeIdx = () => new Date().getDay();

export default function HomeScreen({ navigation }) {
  const [fotoUri, setFotoUri]       = useState(null);
  const [manha, setManha]           = useState([]);
  const [tarde, setTarde]           = useState([]);
  const [noite, setNoite]           = useState([]);
  const [exercicios, setExercicios] = useState([]);
  const [livros, setLivros]         = useState([]);

  const hoje    = new Date();
  const diaIdx  = diaHojeIdx();
  const dataStr = `${String(hoje.getDate()).padStart(2,'0')}/${String(hoje.getMonth()+1).padStart(2,'0')}/${hoje.getFullYear()}`;

  const carregar = useCallback(async () => {
    const [m, t, n, ex, lv] = await Promise.all([
      buscarChecklistHoje('Manhã', diaIdx),
      buscarChecklistHoje('Tarde', diaIdx),
      buscarChecklistHoje('Noite', diaIdx),
      buscarExercicios(),
      buscarLivros(),
    ]);
    setManha(m); setTarde(t); setNoite(n); setExercicios(ex); setLivros(lv);
    const info = await FileSystem.getInfoAsync(FOTO_URI);
    if (info.exists) setFotoUri(FOTO_URI + '?t=' + Date.now());
  }, []);

  useFocusEffect(useCallback(() => { carregar(); }, [carregar]));

  const trocarFoto = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') { Alert.alert('Permissão negada'); return; }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true, aspect: [1,1], quality: 0.7,
    });
    if (!result.canceled) {
      await FileSystem.copyAsync({ from: result.assets[0].uri, to: FOTO_URI });
      setFotoUri(FOTO_URI + '?t=' + Date.now());
    }
  };

  // Marca/desmarca hábito direto na tela inicial e atualiza
  const toggleHabito = async (item, periodo) => {
    await concluirChecklistItem(item.id, !item.concluido_hoje);
    carregar();
  };

  // Renderiza lista de hábitos de um período
  const renderHabitos = (itens, periodo, cor, fundo) => (
    <View style={[s.checkCard, { backgroundColor: fundo }]}>
      <View style={s.checkHeader}>
        <Text style={[s.checkTitulo, { color: cor }]}>{periodo}</Text>
        <TouchableOpacity onPress={() => navigation.navigate('Checklist')}>
          <Text style={[s.verMais, { color: cor }]}>Ver tudo →</Text>
        </TouchableOpacity>
      </View>
      {itens.length === 0
        ? <Text style={s.vazio}>Nenhum hábito para hoje.</Text>
        : itens.slice(0, 4).map(item => (
          <TouchableOpacity key={item.id} style={s.habitoRow} onPress={() => toggleHabito(item, periodo)}>
            <Text style={{ fontSize: 18, color: item.concluido_hoje ? cores.verde : cores.texto2 }}>
              {item.concluido_hoje ? '✓' : '○'}
            </Text>
            <Text style={[s.habitoTxt, item.concluido_hoje && s.riscado]}>{item.nome}</Text>
          </TouchableOpacity>
        ))
      }
      {itens.length > 4 && (
        <TouchableOpacity onPress={() => navigation.navigate('Checklist')}>
          <Text style={[s.verMais, { color: cor, marginTop: 4 }]}>+ {itens.length - 4} mais…</Text>
        </TouchableOpacity>
      )}
    </View>
  );

  return (
    <ScrollView style={s.scroll} contentContainerStyle={s.content}>

      {/* ── Header ── */}
      <View style={s.header}>
        <TouchableOpacity onPress={trocarFoto} style={s.avatarWrap}>
          {fotoUri
            ? <Image source={{ uri: fotoUri }} style={s.avatar} />
            : <Ionicons name="person-circle-outline" size={48} color={cores.texto2} />}
        </TouchableOpacity>
        <Text style={s.diaNome}>{DIAS_PT[hoje.getDay()]}</Text>
        <Text style={s.dataStr}>{dataStr}</Text>
      </View>

      {/* ── Checklist do Dia ── */}
      <Text style={s.secao}>Checklist do Dia</Text>
      {renderHabitos(manha, 'Manhã',  cores.amarelo, cores.manhaFundo)}
      {renderHabitos(tarde, 'Tarde',  cores.azul2,   cores.tardeFundo)}
      {renderHabitos(noite, 'Noite',  cores.roxo,    cores.noiteFundo)}

      {/* ── Treino & Dieta ── */}
      <Text style={s.secao}>Treino & Dieta</Text>
      <View style={s.row}>
        <TouchableOpacity style={[s.card, { backgroundColor: cores.treinoFundo, flex: 1 }]}
          onPress={() => navigation.navigate('Treino')}>
          <Text style={[s.cardTitulo, { color: cores.azul }]}>💪 Treino</Text>
          {exercicios.length === 0
            ? <Text style={s.vazio}>Nenhum exercício.</Text>
            : exercicios.slice(0, 4).map(ex => (
              <View key={ex.id} style={s.miniRow}>
                <Text style={{ color: ex.concluido ? cores.verde : cores.texto2, fontSize: 13 }}>
                  {ex.concluido ? '✓' : '○'}
                </Text>
                <Text style={[s.miniTxt, ex.concluido && { color: cores.cinza, textDecorationLine: 'line-through' }]}>
                  {ex.nome}
                </Text>
              </View>
            ))
          }
        </TouchableOpacity>

        <TouchableOpacity style={[s.card, { backgroundColor: cores.dietaFundo, flex: 1 }]}
          onPress={() => navigation.navigate('Treino')}>
          <Text style={[s.cardTitulo, { color: cores.verde }]}>🥗 Dieta</Text>
          {['Café da manhã','Almoço','Lanche','Jantar','2L de água'].map(item => (
            <View key={item} style={s.miniRow}>
              <Text style={{ color: cores.texto2, fontSize: 13 }}>○</Text>
              <Text style={s.miniTxt}>{item}</Text>
            </View>
          ))}
        </TouchableOpacity>
      </View>

      {/* ── Meu Espaço ── */}
      <Text style={s.secao}>Meu Espaço</Text>
      <View style={s.row}>
        <TouchableOpacity style={[s.card, { backgroundColor: cores.livrosFundo, flex: 1 }]}
          onPress={() => navigation.navigate('Livros')}>
          <Text style={[s.cardTitulo, { color: cores.coral }]}>📚 Livros</Text>
          {livros.length === 0
            ? <Text style={s.vazio}>Sem livros ainda</Text>
            : livros.slice(0, 2).map(l => (
              <Text key={l.id} style={s.miniTxt} numberOfLines={1}>{l.titulo}</Text>
            ))
          }
        </TouchableOpacity>

        <TouchableOpacity style={[s.card, { backgroundColor: cores.diarioFundo, flex: 1 }]}
          onPress={() => navigation.navigate('Diário')}>
          <Text style={[s.cardTitulo, { color: cores.roxo }]}>📓 Diário</Text>
          <Text style={s.vazio}>Escreva como{'\n'}foi seu dia</Text>
          <View style={[s.btnPeq, { backgroundColor: cores.roxo }]}>
            <Text style={s.btnPeqTxt}>Abrir</Text>
          </View>
        </TouchableOpacity>

        <TouchableOpacity style={[s.card, { backgroundColor: '#E8F4FF', flex: 1 }]}
          onPress={() => navigation.navigate('Estudos')}>
          <Text style={[s.cardTitulo, { color: cores.azul }]}>📖 Estudos</Text>
          <Text style={s.vazio}>Pomodoro{'\n'}e foco</Text>
          <View style={[s.btnPeq, { backgroundColor: cores.azul }]}>
            <Text style={s.btnPeqTxt}>Iniciar</Text>
          </View>
        </TouchableOpacity>
      </View>

      {/* ── Botão Livros ── */}
      <TouchableOpacity style={[s.btnGrande, { backgroundColor: cores.azul }]}
        onPress={() => navigation.navigate('Livros')}>
        <Text style={s.btnGrandeTxt}>📖  Ver todos os livros</Text>
      </TouchableOpacity>

    </ScrollView>
  );
}

const s = StyleSheet.create({
  scroll:       { flex: 1, backgroundColor: cores.fundo },
  content:      { padding: 14, paddingBottom: 30, gap: 10 },
  header:       { flexDirection: 'row', alignItems: 'center', marginBottom: 4 },
  avatarWrap:   { width: 48, height: 48, borderRadius: 24, overflow: 'hidden', marginRight: 8 },
  avatar:       { width: 48, height: 48 },
  diaNome:      { flex: 1, fontSize: 20, fontWeight: '700', color: cores.texto, textAlign: 'center' },
  dataStr:      { fontSize: 13, color: cores.texto2, minWidth: 86, textAlign: 'right' },
  secao:        { fontSize: 15, fontWeight: '700', color: cores.texto, marginTop: 4 },
  checkCard:    { borderRadius: 14, padding: 12, ...sombra },
  checkHeader:  { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 },
  checkTitulo:  { fontSize: 13, fontWeight: '700' },
  verMais:      { fontSize: 12, fontWeight: '600' },
  habitoRow:    { flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 6,
                  borderBottomWidth: 0.5, borderColor: cores.borda },
  habitoTxt:    { fontSize: 14, color: cores.texto, flex: 1 },
  riscado:      { textDecorationLine: 'line-through', color: cores.cinza },
  card:         { borderRadius: 14, padding: 10, ...sombra, marginBottom: 2 },
  cardTitulo:   { fontSize: 13, fontWeight: '700', marginBottom: 6 },
  miniRow:      { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 3 },
  miniTxt:      { fontSize: 12, color: cores.texto, flex: 1 },
  vazio:        { fontSize: 12, color: cores.texto2, fontStyle: 'italic' },
  row:          { flexDirection: 'row', gap: 8 },
  btnPeq:       { borderRadius: 8, paddingVertical: 5, paddingHorizontal: 10, marginTop: 6, alignSelf: 'flex-start' },
  btnPeqTxt:    { color: cores.branco, fontSize: 12, fontWeight: '600' },
  btnGrande:    { borderRadius: 12, padding: 13, alignItems: 'center', marginTop: 4 },
  btnGrandeTxt: { color: cores.branco, fontSize: 14, fontWeight: '600' },
});
