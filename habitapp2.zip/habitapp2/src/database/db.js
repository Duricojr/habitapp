import * as SQLite from 'expo-sqlite';

let _db = null;

async function getDb() {
  if (_db) return _db;
  _db = await SQLite.openDatabaseAsync('habitapp.db');
  return _db;
}

export async function inicializar() {
  const db = await getDb();
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS exercicios (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nome TEXT NOT NULL, duracao TEXT, concluido INTEGER DEFAULT 0);
    CREATE TABLE IF NOT EXISTS tarefas (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      texto TEXT NOT NULL, concluido INTEGER DEFAULT 0);
    CREATE TABLE IF NOT EXISTS checklist (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nome TEXT NOT NULL, periodo TEXT NOT NULL, dias TEXT DEFAULT '0123456');
    CREATE TABLE IF NOT EXISTS checklist_log (
      item_id INTEGER, data TEXT, PRIMARY KEY (item_id, data));
    CREATE TABLE IF NOT EXISTS diario (
      data TEXT PRIMARY KEY, texto TEXT, humor TEXT);
    CREATE TABLE IF NOT EXISTS livros (
      id INTEGER PRIMARY KEY AUTOINCREMENT, titulo TEXT NOT NULL, caminho TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS pace (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      atual TEXT DEFAULT '5:30', meta TEXT DEFAULT '5:00', km TEXT DEFAULT '0');
    INSERT OR IGNORE INTO pace (id, atual, meta, km) VALUES (1,'5:30','5:00','0');
  `);
}

export async function buscarExercicios() {
  const db = await getDb();
  return db.getAllAsync('SELECT * FROM exercicios');
}
export async function adicionarExercicio(nome, duracao) {
  const db = await getDb();
  await db.runAsync('INSERT INTO exercicios (nome, duracao) VALUES (?,?)', [nome, duracao]);
}
export async function concluirExercicio(id, estado) {
  const db = await getDb();
  await db.runAsync('UPDATE exercicios SET concluido=? WHERE id=?', [estado ? 1 : 0, id]);
}

export async function buscarTarefas() {
  const db = await getDb();
  return db.getAllAsync('SELECT * FROM tarefas ORDER BY concluido, id DESC');
}
export async function adicionarTarefa(texto) {
  const db = await getDb();
  await db.runAsync('INSERT INTO tarefas (texto) VALUES (?)', [texto]);
}
export async function concluirTarefa(id, estado) {
  const db = await getDb();
  await db.runAsync('UPDATE tarefas SET concluido=? WHERE id=?', [estado ? 1 : 0, id]);
}

export async function buscarChecklistHoje(periodo, diaIdx) {
  const db   = await getDb();
  const hoje = new Date().toISOString().split('T')[0];
  const rows = await db.getAllAsync('SELECT * FROM checklist WHERE periodo=?', [periodo]);
  const result = [];
  for (const r of rows) {
    if ((r.dias || '0123456').includes(String(diaIdx))) {
      const log = await db.getFirstAsync(
        'SELECT 1 FROM checklist_log WHERE item_id=? AND data=?', [r.id, hoje]
      );
      result.push({ ...r, concluido_hoje: !!log });
    }
  }
  return result;
}
export async function adicionarChecklistItem(nome, periodo, dias) {
  const db = await getDb();
  await db.runAsync('INSERT INTO checklist (nome, periodo, dias) VALUES (?,?,?)', [nome, periodo, dias]);
}
export async function concluirChecklistItem(id, estado) {
  const db   = await getDb();
  const hoje = new Date().toISOString().split('T')[0];
  if (estado) {
    await db.runAsync('INSERT OR IGNORE INTO checklist_log (item_id, data) VALUES (?,?)', [id, hoje]);
  } else {
    await db.runAsync('DELETE FROM checklist_log WHERE item_id=? AND data=?', [id, hoje]);
  }
}

export async function buscarDiario(data) {
  const db = await getDb();
  return db.getFirstAsync('SELECT * FROM diario WHERE data=?', [data]);
}
export async function salvarDiario(data, texto, humor) {
  const db = await getDb();
  await db.runAsync(
    `INSERT INTO diario (data,texto,humor) VALUES (?,?,?)
     ON CONFLICT(data) DO UPDATE SET texto=excluded.texto, humor=excluded.humor`,
    [data, texto, humor]
  );
}

export async function buscarLivros() {
  const db = await getDb();
  return db.getAllAsync('SELECT * FROM livros');
}
export async function adicionarLivro(titulo, caminho) {
  const db = await getDb();
  await db.runAsync('INSERT INTO livros (titulo, caminho) VALUES (?,?)', [titulo, caminho]);
}

export async function buscarPace() {
  const db = await getDb();
  return db.getFirstAsync('SELECT * FROM pace WHERE id=1');
}
export async function salvarPace(atual, meta, km) {
  const db = await getDb();
  await db.runAsync('UPDATE pace SET atual=?, meta=?, km=? WHERE id=1', [atual, meta, km]);
}
