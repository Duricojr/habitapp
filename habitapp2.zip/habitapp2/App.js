import { Ionicons } from '@expo/vector-icons';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { registerRootComponent } from 'expo';
import { StatusBar } from 'expo-status-bar';
import { useEffect } from 'react';
import { SafeAreaProvider } from 'react-native-safe-area-context';

import { inicializar } from './src/database/db';
import ChecklistScreen from './src/screens/ChecklistScreen';
import DiarioScreen from './src/screens/DiarioScreen';
import EstudosScreen from './src/screens/EstudosScreen';
import HomeScreen from './src/screens/HomeScreen';
import LivrosScreen from './src/screens/LivrosScreen';
import TreinoScreen from './src/screens/TreinoScreen';
import { cores } from './src/theme';

const Tab   = createBottomTabNavigator();
const Stack = createNativeStackNavigator();

const ICONES = {
  'Início':    ['home',    'home-outline'],
  'Checklist': ['checkbox','checkbox-outline'],
  'Treino':    ['barbell', 'barbell-outline'],
  'Estudos':   ['book',    'book-outline'],
  'Diário':    ['journal', 'journal-outline'],
  'Livros':    ['library', 'library-outline'],
};

function Tabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor:   cores.azul,
        tabBarInactiveTintColor: cores.texto2,
        tabBarStyle: {
          backgroundColor: cores.branco,
          borderTopColor:  cores.borda,
          height: 60,
          paddingBottom: 8,
        },
        tabBarLabelStyle: { fontSize: 10, fontWeight: '600' },
        tabBarIcon: ({ focused, color, size }) => {
          const [ativo, inativo] = ICONES[route.name] || ['ellipse','ellipse-outline'];
          return <Ionicons name={focused ? ativo : inativo} size={size} color={color} />;
        },
      })}
    >
      <Tab.Screen name="Início"    component={HomeScreen} />
      <Tab.Screen name="Checklist" component={ChecklistScreen} />
      <Tab.Screen name="Treino"    component={TreinoScreen} />
      <Tab.Screen name="Estudos"   component={EstudosScreen} />
      <Tab.Screen name="Diário"    component={DiarioScreen} />
      <Tab.Screen name="Livros"    component={LivrosScreen} />
    </Tab.Navigator>
  );
}

function App() {
  useEffect(() => { inicializar(); }, []);

  return (
    <SafeAreaProvider>
      <StatusBar style="dark" />
      <NavigationContainer>
        <Stack.Navigator screenOptions={{ headerShown: false }}>
          <Stack.Screen name="Main"      component={Tabs} />
        </Stack.Navigator>
      </NavigationContainer>
    </SafeAreaProvider>
  );
}

registerRootComponent(App);
